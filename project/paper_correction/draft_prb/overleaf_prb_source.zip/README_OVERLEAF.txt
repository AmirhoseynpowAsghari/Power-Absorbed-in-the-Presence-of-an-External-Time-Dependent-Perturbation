Overleaf test package

Contents: draft_prb.tex, draft_references.bib, and the 16 existing figure assets in the figures/ hierarchy.

To test: create a new Overleaf project by uploading this ZIP. Set draft_prb.tex as the main document. Use pdfLaTeX (the standard REVTeX 4.2 distribution) and allow BibTeX to run for the apsrev4-2 references. The source uses relative paths under figures/ and does not require the original repository folder layout.

This is a source-only Overleaf package; it excludes the prebuilt PDFs and does not modify or regenerate any figure data. The manuscript remains a conditional constant-vertex model study; see the manuscript text for scope and caveats.
