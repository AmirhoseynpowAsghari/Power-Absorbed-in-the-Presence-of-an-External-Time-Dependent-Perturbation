Overleaf package for the revised strict/relaxed policy-comparison manuscript.

Contents: draft_prb.tex, draft_references.bib, and the existing image assets referenced by the source under figures/.

To use: upload this ZIP as a new Overleaf project, select draft_prb.tex as the main file, and compile with REVTeX 4.2 and BibTeX. Graphics paths are internal to the package.

The relaxed-policy plots are separate companions to the strict-policy figures so that each policy remains visually distinct. No numerical data were recalculated for this package. The temperature/gap family, branch-decomposition, and SOC vertex-sensitivity figures removed from the draft are not included. The strict peaks are more visible because the relaxed sampled peaks lie at or near the low-U edge and have out-of-band zero-temperature roots; this is a difference in accepted root domain, not a response enhancement caused by the strict policy. The manuscript remains a conditional constant-vertex model study, not a material-specific finite-q acoustic prediction.
